# Verdadero o Falso — Oración y Sanidad

Juego interactivo de **Verdadero o Falso** centrado en temas de oración y sanidad, diseñado para jugar en pareja.
Cada pregunta incluye una cita bíblica de referencia.


## Cómo usar
1. Descarga y extrae el ZIP.
2. Abre `verdadero-falso-oracion.html` en tu navegador (doble clic).
3. Introduce los nombres de los jugadores y pulsa **Iniciar juego**.
4. Si la casilla de pantalla completa está activada, el navegador pedirá permiso para entrar en fullscreen.
5. Disfruta el juego: cada pregunta tiene 15 segundos y las puntuaciones varían según la dificultad.

## Publicar en GitHub Pages
1. Crea un repo público en GitHub (por ejemplo `verdadero-falso-oracion`).
2. Sube los archivos del ZIP (incluyendo `verdadero-falso-oracion.html` y la carpeta `sounds/`).
3. En Settings → Pages, selecciona la rama `main` (root) y guarda.
4. Accede a: `https://<tuusuario>.github.io/verdadero-falso-oracion/`

## Créditos
Desarrollado por Isauro Vlad
